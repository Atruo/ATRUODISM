
using System;

namespace CervezUAGenNHibernate.Enumerated.CervezUA
{
public enum MetodoPagoEnum { TarjetaCredito=1, PayPal=2, Contrarembolso=3 };
}

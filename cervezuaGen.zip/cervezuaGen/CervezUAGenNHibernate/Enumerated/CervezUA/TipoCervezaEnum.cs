
using System;

namespace CervezUAGenNHibernate.Enumerated.CervezUA
{
public enum TipoCervezaEnum { Abadia=1, ALE=2, LagerPilsner=3, Lambica=4, PaleALEIPA=5, PorterStout=6, Temporada=7, Trapense=8, Trigo=9 };
}

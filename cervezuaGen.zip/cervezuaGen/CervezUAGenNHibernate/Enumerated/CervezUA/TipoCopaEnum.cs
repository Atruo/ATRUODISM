
using System;

namespace CervezUAGenNHibernate.Enumerated.CervezUA
{
public enum TipoCopaEnum { Globo=1, Tubo=2, OldFashioned=3 };
}

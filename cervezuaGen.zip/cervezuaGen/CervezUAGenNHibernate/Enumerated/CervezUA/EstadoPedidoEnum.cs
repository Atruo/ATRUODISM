
using System;

namespace CervezUAGenNHibernate.Enumerated.CervezUA
{
public enum EstadoPedidoEnum { EsperaPago=1, PagoAceptado=2, Procesando=3, Enviado=4, Cancelado=5 };
}

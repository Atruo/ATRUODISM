
using System;

namespace CervezUAGenNHibernate.Enumerated.CervezUA
{
public enum TipoUsuarioEnum { Normal=1, Critico=2, Admin=3 };
}

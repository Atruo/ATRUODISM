
using System;
using System.Text;
using System.Collections.Generic;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using CervezUAGenNHibernate.Exceptions;
using CervezUAGenNHibernate.EN.CervezUA;
using CervezUAGenNHibernate.CAD.CervezUA;


/*PROTECTED REGION ID(usingCervezUAGenNHibernate.CEN.CervezUA_Usuario_obtenerNUSUARIO) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace CervezUAGenNHibernate.CEN.CervezUA
{
public partial class UsuarioCEN
{
public string ObtenerNUSUARIO (string token)
{
        /*PROTECTED REGION ID(CervezUAGenNHibernate.CEN.CervezUA_Usuario_obtenerNUSUARIO) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method ObtenerNUSUARIO() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}

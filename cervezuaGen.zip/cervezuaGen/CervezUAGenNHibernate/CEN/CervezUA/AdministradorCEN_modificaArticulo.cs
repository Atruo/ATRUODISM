
using System;
using System.Text;
using System.Collections.Generic;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using CervezUAGenNHibernate.Exceptions;
using CervezUAGenNHibernate.EN.CervezUA;
using CervezUAGenNHibernate.CAD.CervezUA;


/*PROTECTED REGION ID(usingCervezUAGenNHibernate.CEN.CervezUA_Administrador_modificaArticulo) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace CervezUAGenNHibernate.CEN.CervezUA
{
public partial class AdministradorCEN
{
public void ModificaArticulo (string p_oid)
{
        /*PROTECTED REGION ID(CervezUAGenNHibernate.CEN.CervezUA_Administrador_modificaArticulo) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method ModificaArticulo() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}


using System;
using System.Text;
using System.Collections.Generic;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using CervezUAGenNHibernate.Exceptions;
using CervezUAGenNHibernate.EN.CervezUA;
using CervezUAGenNHibernate.CAD.CervezUA;


/*PROTECTED REGION ID(usingCervezUAGenNHibernate.CEN.CervezUA_Articulo_menosStock) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace CervezUAGenNHibernate.CEN.CervezUA
{
public partial class ArticuloCEN
{
public void MenosStock (int p_oid)
{
        /*PROTECTED REGION ID(CervezUAGenNHibernate.CEN.CervezUA_Articulo_menosStock) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method MenosStock() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}
